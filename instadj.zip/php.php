<?php

echo sqlite_libversion();

?>